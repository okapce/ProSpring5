package com.apress.prospring5.ch2.decoupled;

public interface MessageProvider {
    String getMessage();
}
