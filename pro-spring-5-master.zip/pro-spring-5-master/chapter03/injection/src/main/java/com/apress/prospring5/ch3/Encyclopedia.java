package com.apress.prospring5.ch3;

public class Encyclopedia {
    
}