package com.apress.prospring5.ch5.introduction;

public interface IsModified {
    boolean isModified();
}
