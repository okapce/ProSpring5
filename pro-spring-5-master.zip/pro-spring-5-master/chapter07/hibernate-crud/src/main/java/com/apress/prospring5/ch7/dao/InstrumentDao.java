package com.apress.prospring5.ch7.dao;

import com.apress.prospring5.ch7.entities.Instrument;
import com.apress.prospring5.ch7.entities.Singer;

/**
 * Created by iuliana.cosmina on 4/23/17.
 */
public interface InstrumentDao {

	Instrument save(Instrument instrument);

}
